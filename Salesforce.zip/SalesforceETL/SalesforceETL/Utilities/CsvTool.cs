﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using Salesforce.Force;
using System.Data.OleDb;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace SalesforceETL.Utilities
{
    class CsvTool
    {
        public List<string> listA {get; set;}
        public List<string> listB { get; set; }
        public CsvTool()
        {
            
        }

       
        public bool SaveDataGridViewToCSV(string orgName, string objName, DataGridView dgv)
        {
            var sb = new StringBuilder();

            var headers = dgv.Columns.Cast<DataGridViewColumn>();
            sb.AppendLine(string.Join(",", headers.Select(column => "\"" + column.HeaderText + "\"").ToArray()));
            int i = 0;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                var cells = row.Cells.Cast<DataGridViewCell>();
                sb.AppendLine(string.Join(",", cells.Select(cell => "\"" + cell.Value + "\"").ToArray()));
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV (*.csv)|*.csv";
            sfd.FileName = orgName + "." + objName + ".describe.csv";
            bool fileError = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);
                    }
                    catch (IOException ex)
                    {
                        fileError = true;
                        MessageBox.Show("データをディスクに書き込めませんでした：" + ex.Message);
                    }
                }
                if (!fileError)
                {
                    try
                    {

                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                        MessageBox.Show("データのエクスポートに成功しました。", "情報");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("エラー:" + ex.Message);
                    }
                }
            }

            return fileError;
        }

        public bool JsonToCSV(string orgName, string objName, DataGridView dgv)
        {
            var sb = new StringBuilder();

            var headers = dgv.Columns.Cast<DataGridViewColumn>();
            sb.AppendLine(string.Join(",", headers.Select(column => "\"" + column.HeaderText + "\"").ToArray()));
            int i = 0;
            foreach (DataGridViewRow row in dgv.Rows)
            {
                var cells = row.Cells.Cast<DataGridViewCell>();
                sb.AppendLine(string.Join(",", cells.Select(cell => "\"" + cell.Value + "\"").ToArray()));
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "CSV (*.csv)|*.csv";
            sfd.FileName = orgName + "." + objName + ".describe.csv";
            bool fileError = false;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(sfd.FileName))
                {
                    try
                    {
                        File.Delete(sfd.FileName);
                    }
                    catch (IOException ex)
                    {
                        fileError = true;
                        MessageBox.Show("データをディスクに書き込めませんでした：" + ex.Message);
                    }
                }
                if (!fileError)
                {
                    try
                    {

                        File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                        MessageBox.Show("データのエクスポートに成功しました。", "情報");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("エラー:" + ex.Message);
                    }
                }
            }

            return fileError;
        }

        /**
         * @description CSVファイルを読み込み、DataGridViewに表示する。
         * @param Orgの名称
         * @param DataGridView
         * */
        public async Task ReadCSV(ForceClient forceClient, string orgName, string clsName, string csvFilePath, DataGridView dataGridView)
        {
            var describe = await forceClient.DescribeAsync<JObject>(clsName);
            List<string> colHeaders = new List<string>();
            foreach (var field in (JArray)describe["fields"])
            {
                colHeaders.Add((string)field["label"]);
            }

            FileStream fileStream = null;
            try
            {
                fileStream = File.Open(csvFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            }
            catch (Exception ex)
            {
                MessageBox.Show("CSVファイルは開けませんでした。", "警告");
            }

            DataTable table = new DataTable();
            bool isColumnCreated = false;
            using (StringReader reader = new StringReader(new StreamReader(fileStream, Encoding.UTF8).ReadToEnd()))
            {
                while (reader.Peek() != -1)
                {
                    string line = reader.ReadLine();

                    if (line == null || line.Length == 0)
                        continue;

                        string[] values = line.Split(',');

                        if (!isColumnCreated)
                        {
                            for (int i = 0; i < colHeaders.Count(); i++)
                            {
                                table.Columns.Add(colHeaders[i]+i);
                            }
                            isColumnCreated = true;
                        }

                        DataRow row = table.NewRow();

                        for (int i = 0; i < values.Count(); i++)
                        {
                            row[i] = values[i];
                        }
                        table.Rows.Add(row);
                    }
                }

                dataGridView.DataSource = table;

        }
        /// <summary>
        /// CSVファイルからDataTableを返す
        /// </summary>
        /// <param name="strFilePath">CSVファイルパス</param>
        /// <param name="isInHeader">1行目はヘッダー扱いとするか</param>
        /// <returns></returns>
        public async Task<DataTable> GetDataTableFromCSV(String strFilePath, Boolean isInHeader = true)
        {
            DataTable dt = new DataTable();
            String strInHeader = isInHeader ? "YES" : "NO";                // ヘッダー設定
            String strCon = "Provider=Microsoft.ACE.OLEDB.12.0;"      // プロバイダ設定
                                                                      //= "Provider=Microsoft.Jet.OLEDB.4.0;"     // Jetでやる場合
                                + "Data Source=" + Path.GetDirectoryName(strFilePath) + "\\; "          // ソースファイル指定
                                + "Extended Properties=\"Text;HDR=" + strInHeader + ";FMT=Delimited\"";
            OleDbConnection con = new OleDbConnection(strCon);
            String strCmd = "SELECT * FROM [" + Path.GetFileName(strFilePath) + "]";

            // 読み込み
            await Task.Run(() =>
            {
                OleDbCommand cmd = new OleDbCommand(strCmd, con);
                OleDbDataAdapter adp = new OleDbDataAdapter(cmd);
                adp.Fill(dt);
            });
            

            return dt;
        }
        public async Task SaveToCSV(DataTable dt, string fileName, bool hasHeader, string encode, string separator, string quote, string replace, bool append)
        {
            int rows = dt.Rows.Count;
            int cols = dt.Columns.Count;
            string text;
            
            await Task.Run(() =>
            {
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                //保存用のファイルを開く。上書きモードで。
                StreamWriter writer = new StreamWriter(fileName, append, Encoding.GetEncoding(encode));
                //カラム名を保存するか
                if (hasHeader)
                {
                    //カラム名を保存する場合
                    for (int i = 0; i < cols; i++)
                    {
                        //カラム名を取得
                        if (quote != "")
                        {
                            text = dt.Columns[i].ColumnName.Replace(quote, replace);
                        }
                        else
                        {
                            text = dt.Columns[i].ColumnName;
                        }
                        if (i != cols - 1)
                        {
                            writer.Write(quote + text + quote + separator);
                        }
                        else
                        {
                            writer.WriteLine(quote + text + quote);
                        }
                    }
                }
                //データの保存処理
                for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < cols; j++)
                    {
                        if (quote != "")
                        {
                            text = dt.Rows[i][j].ToString().Replace(quote, replace);
                        }
                        else
                        {
                            text = dt.Rows[i][j].ToString();
                        }
                        if (j != cols - 1)
                        {
                            writer.Write(quote + text + quote + separator);
                        }
                        else
                        {
                            writer.WriteLine(quote + text + quote);
                        }
                    }
                }
                //ストリームを閉じる
                writer.Close();
            });
                
        }
        public async Task<DataTable> GetDataTabletFromCSVFile(string csv_file_path, string encode)
        {
            DataTable csvData = new DataTable();
            
            try
            {
                await Task.Run(() =>
                {
                    Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                    using (TextFieldParser csvReader = new TextFieldParser(csv_file_path, Encoding.GetEncoding(encode)))
                    {
                        csvReader.SetDelimiters(new string[] { "," });
                        csvReader.HasFieldsEnclosedInQuotes = true;

                        string[] colFields = csvReader.ReadFields();
                        foreach (string column in colFields)
                        {
                            DataColumn datecolumn = new DataColumn(column);
                            datecolumn.AllowDBNull = true;
                            csvData.Columns.Add(datecolumn);
                        }
                        while (!csvReader.EndOfData)
                        {
                            string[] fieldData = csvReader.ReadFields();

                            for (int i = 0; i < fieldData.Length; i++)
                            {
                                if (fieldData[i] == "")
                                {
                                    fieldData[i] = null;
                                }
                            }
                            csvData.Rows.Add(fieldData);
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return csvData;
        }
        /// <summary>
        /// CSVファイルからマスキングしたDataTableを作成する
        /// </summary>
        /// <param name=" masking_config_path">マスクキング設定用CSVファイル</param>
        /// <param name="csv_file_path">マスクキングするCSVファイル</param>
        /// <param name="encode">文字コード：shift-jis or UTF-8</param>
        /// <returns>マスキングしたデータテーブル</returns>
        public async Task<DataTable> GetMaskedDataTabletFromCSVFile(string masking_config_path, string csv_file_path, string encode)
        {
            DataTable maskingDt = await GetDataTabletFromCSVFile(masking_config_path, "UTF-8");
            DataTable csvData = new DataTable();

            try
            {
                await Task.Run(() =>
                {
                    Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
                    using (TextFieldParser csvReader = new TextFieldParser(csv_file_path, Encoding.GetEncoding(encode)))
                    {
                        csvReader.SetDelimiters(new string[] { "," });
                        csvReader.HasFieldsEnclosedInQuotes = true;

                        string[] colFields = csvReader.ReadFields();
                        foreach (string column in colFields)
                        {

                            DataColumn datecolumn = new DataColumn(column);
                            datecolumn.AllowDBNull = true;
                            csvData.Columns.Add(datecolumn);
                        }

                        while (!csvReader.EndOfData)
                        {
                            string[] fieldData = csvReader.ReadFields();

                            for (int i = 0; i < fieldData.Length; i++)
                            {
                                if (fieldData[i] == "")
                                {
                                    fieldData[i] = " ";
                                }                                
                            }
                            csvData.Rows.Add(fieldData);

                        }
                        string query = "マスキング必須=\'TRUE\'";
                        //MessageBox.Show(query);
                        DataRow[] csvDataRow = csvData.Select();
                        DataRow[] drs = maskingDt.Select(query);

                        foreach (DataRow csvdr in csvDataRow)
                            for (int i = 0; i < csvData.Rows.Count; i++)
                            {
                                foreach (DataRow dr in drs)
                                {

                                    if (csvData.Columns.Contains(dr["API参照名"].ToString()))
                                    {
                                        if (dr["API参照名"].ToString() == "Name")
                                        {
                                            csvData.Rows[i][dr["API参照名"].ToString()] = randomLastName(2) + " " + randomFirstName(2);
                                        }
                                        else if (dr["API参照名"].ToString() == "LastName")
                                        {
                                            csvData.Rows[i][dr["API参照名"].ToString()] = randomLastName(2);
                                        }
                                        else if (dr["API参照名"].ToString() == "FirstName")
                                        {
                                            csvData.Rows[i][dr["API参照名"].ToString()] = randomFirstName(2);
                                        }
                                        else if (new EmailAddressAttribute().IsValid(csvData.Rows[i][dr["API参照名"].ToString()]))
                                        {
                                            csvData.Rows[i][dr["API参照名"].ToString()] = randomEmail(8);
                                        }
                                        else if (csvData.Rows[i][dr["API参照名"].ToString()].ToString().Trim().Length > 0)
                                        {
                                            csvData.Rows[i][dr["API参照名"].ToString()] = randomText(8);
                                        }
                                        
                                        //MessageBox.Show(csvData.Rows[i][dr["API参照名"].ToString()].ToString());
                                    }

                                }

                            }

                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("以下のエラーで終了しました:" + ex.Message, "警告");
            }
            return csvData;
        }
        /// <summary>
        /// 受け取ったデータグリッドビューをDataTableに格納してして返す
        /// </summary>
        /// <param name="dtgrdvwTarget">テーブルにしたいデータグリッドビュー</param>
        /// <param name="dtResult">データグリッドビューの値の抽出先</param>
        /// <returns>データテーブル</returns>
        public DataTable RetDtgrdvwValue(DataGridView dtgrdvwTarget, DataTable dtResult)
        {
            for (int row = 0; row < dtgrdvwTarget.Rows.Count - 1; row++)
            {
                DataRow drResult = dtResult.NewRow();
                for (int col = 0; col < dtgrdvwTarget.Columns.Count; col++)
                {
                    drResult[col] = dtgrdvwTarget.Rows[row].Cells[col].Value;
                }
                dtResult.Rows.InsertAt(drResult, row);
            }
            return dtResult;
        }

        public static DataTable jsonStringToTable(string jsonContent)
        {
            DataTable dt = JsonConvert.DeserializeObject<DataTable>(jsonContent);
            return dt;
        }


        public void jsonToCsvFile(string[] str, string fileName, string encode, bool append)
        {          
            try
            {

                // ファイルを開く
                StreamWriter file = new StreamWriter(fileName, append, Encoding.GetEncoding(encode));
                for (int i = 0; i < str.Length; i += 2)
                {
                    file.WriteLine(string.Format("{0},{1}", str[i], str[i + 1]));
                }
                file.Close();
                MessageBox.Show("ファイルに書き込みました", "情報");
            }
            catch (Exception e)
            {
                MessageBox.Show("CSVファイルの書き出しに失敗しました。\r\nエラーの内容:\r\n" + e.Message, "警告");       // エラーメッセージを表示
            }
        }
        
        private static string randomText(int length)
        {
            var list = "0123456789あいうえおかきくけこさしすせそなにぬねのはひふへほまみむめもやゆよらりるれろわをん".ToList();

            Random rand = new Random();
            StringBuilder sb = new StringBuilder();

            for (var i = 0; i < length; i++) {
                sb.Append(list.ElementAt(rand.Next(list.Count())));
            }

            return sb.ToString();
        }

        private static string randomEmail(int length)
        {
            var list = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToList();

            Random rand = new Random();
            StringBuilder sb = new StringBuilder();

            for (var i = 0; i < length; i++)
            {
                sb.Append(list.ElementAt(rand.Next(list.Count())));
            }
            sb.Append("@example.com");

            return sb.ToString();
        }

        private static string randomLastName(int length)
        {
            var list = "一二三四五六七八九十田中鈴木佐藤村後井上下原川崎谷山子野谷中本石加島澳松大日東西南北金多窪久保矢屋橋月池服部水竹千平亀吉埼口今".ToList();

            Random rand = new Random();
            StringBuilder sb = new StringBuilder();

            for (var i = 0; i < length; i++)
            {
                sb.Append(list.ElementAt(rand.Next(list.Count())));
            }

            return sb.ToString();
        }

        private static string randomFirstName(int length)
        {
            var list = "一二三四五六七八九十雅良男太郎次子芳吉正昌匡凛蒼律陽翔結愛詩樹剛強史勉敦進力早孜努又篤裕雄優有悠友里美晴菜穂謙拓真也月祥理恵稚奈樹大嗣詩織".ToList();

            Random rand = new Random();
            StringBuilder sb = new StringBuilder();

            for (var i = 0; i < length; i++)
            {
                sb.Append(list.ElementAt(rand.Next(list.Count())));
            }

            return sb.ToString();
        }
    }
}
